MAD2 project
